package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Bookdao {

	public String url="jdbc:mysql://localhost:3306/employee",user="root",pass="root";
	Connection con=null;
	PreparedStatement ps=null;
	String q;
	ResultSet rs=null;
	
	public Bookdao() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection(url,user,pass);	
	}
	
	public boolean SaveBook(Book obj) throws SQLException {
		
		q="insert into book values(?,?,?,?)";
		
		ps=con.prepareStatement(q);
		
		ps.setInt(1, obj.getBid());
		ps.setString(2, obj.getBname());
		ps.setString(3, obj.getBauthor());
		ps.setDouble(4, obj.getPrice());
		
		int r=ps.executeUpdate();
		
		if(r>0)
			return true;
		else
			return false;
		
		
	}
	
	public boolean UpdateBook(Book obj) throws SQLException {
		q="update book set price=? where bid=?";
		
		ps=con.prepareStatement(q);
		
		ps.setDouble(1, obj.getPrice());
		ps.setInt(2, obj.getBid());
		
		int r=ps.executeUpdate();
		
		if(r>0)
			return true;
		else
			return false;
		
		
	}
	
	public boolean deleteBook(int bid) throws SQLException {
		q="delete from book where bid=?";
		
		ps=con.prepareStatement(q);
		
		ps.setInt(1, bid);
		
		int r=ps.executeUpdate();
		
		if(r>0)
			return true;
		else
			return false;
		
	}
	
	public ResultSet searchBook(int bid) throws SQLException {
		
		q="select * from book where bid=?";
		
		ps=con.prepareStatement(q);
		
		ps.setInt(1, bid);
		
		rs=ps.executeQuery();
		
		return rs;
	}
	
	
}
