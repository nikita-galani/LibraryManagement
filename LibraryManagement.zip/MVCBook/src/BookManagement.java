import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Book;
import model.Bookdao;

public class BookManagement extends JFrame implements ActionListener{

	Container cp;
	JLabel lid,lname,lauthor,lprice;
	JTextField tid,tname,tauthor,tprice;
	JButton bsave,bupdate,bdelete,bsearch,bclear;
	Bookdao dao;
	
	public BookManagement(String t) throws ClassNotFoundException, SQLException {
		super(t);
		cp=getContentPane();
		cp.setLayout(new GridLayout(7,2,5,5));
		
		dao=new Bookdao();
		
		lid=new JLabel("Book id");
		tid=new JTextField();
		
		lname=new JLabel("Name");
		tname=new JTextField();
		
		lauthor=new JLabel("Author");
		tauthor=new JTextField();
		
		lprice=new JLabel("Price");
		tprice=new JTextField();
		
		bsave=new JButton("Save");
		bupdate=new JButton("Update");
		bdelete=new JButton("Delete");
		bsearch=new JButton("Search");
		bclear=new JButton("Clear");
		
		cp.add(lid);
		cp.add(tid);
		cp.add(lname);
		cp.add(tname);
		cp.add(lauthor);
		cp.add(tauthor);
		cp.add(lprice);
		cp.add(tprice);
		cp.add(bsave);
		cp.add(bupdate);
		cp.add(bdelete);
		cp.add(bsearch);
		cp.add(bclear);
		
		
		bsave.addActionListener(this);
		bupdate.addActionListener(this);
		bdelete.addActionListener(this);
		bsearch.addActionListener(this);
		bclear.addActionListener(this);
		
		
		setSize(500, 500);
		setVisible(true);
		
	}
	
	
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
		new BookManagement("Book management");
		
		
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		try {
		if(e.getSource()==bsave) {
			int bid=Integer.parseInt(tid.getText());
			String nm=tname.getText();
			String au=tauthor.getText();
			double p=Double.parseDouble(tprice.getText());
			
			Book obj=new Book(bid,nm,au,p);
		
			boolean r;
			
				r = dao.SaveBook(obj);
			
			if(r)
				JOptionPane.showMessageDialog(this, "Record inserted..");
		} else if(e.getSource()==bupdate) {
			int bid=Integer.parseInt(tid.getText());
			double p=Double.parseDouble(tprice.getText());
			Book obj=new Book(bid,null,null,p); 
			
			boolean r;
			r=dao.UpdateBook(obj);
			
			if(r)
				JOptionPane.showMessageDialog(this, "Record Updated..");
			else
				JOptionPane.showMessageDialog(this, "Record not found");
		}else
			if(e.getSource()==bdelete) {
				int bid=Integer.parseInt(tid.getText());
				
				Boolean r=dao.deleteBook(bid);
				
				if(r)
					JOptionPane.showMessageDialog(this, "Record deleted..");
				else
					JOptionPane.showMessageDialog(this, "Record not found");
			}else
				if(e.getSource()==bsearch) {
					
					int bid=Integer.parseInt(tid.getText());
					ResultSet rs=dao.searchBook(bid);
					if(rs.next()) {
						JOptionPane.showMessageDialog(this, rs.getInt(1)+"  "+
															rs.getString(2)+"  "+
															rs.getString(3)+"  "+
															rs.getDouble(4));
					}else
						JOptionPane.showMessageDialog(this,"Record not found");
					
				}else 
					if(e.getSource()==bclear) {
					
						tid.setText("");
						tname.setText("");
						tauthor.setText("");
						tprice.setText("");
						
					}
		
		
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

